<?php
if(roam_mikado_show_comments()){
    comments_template('', true);
}