<div class="mkdf-post-info-category">
    <span aria-hidden="true" class="icon_tag"></span><?php the_category(', '); ?>
</div>