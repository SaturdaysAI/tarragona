<?php

include_once MIKADO_MEMBERSHIP_SHORTCODES_PATH . '/reset-password/functions.php';
include_once MIKADO_MEMBERSHIP_SHORTCODES_PATH . '/reset-password/reset-password.php';