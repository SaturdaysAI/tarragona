<div class="mkdf-social-register-holder">
	<form method="post" class="mkdf-register-form">
		<fieldset>
			<div>
				<input type="text" name="user_register_name" id="user_register_name" placeholder="<?php esc_attr_e( 'User Name', 'mikado-membership' ) ?>" value="" required
				       pattern=".{3,}" title="<?php esc_attr_e( 'Three or more characters', 'mikado-membership' ); ?>"/>
			</div>
			<div>
				<input type="email" name="user_register_email" id="user_register_email" placeholder="<?php esc_attr_e( 'Email', 'mikado-membership' ) ?>" value="" required />
			</div>
            <div>
                <input type="password" name="user_register_password" id="user_register_password" placeholder="<?php esc_attr_e('Password','mikado-membership') ?>" value="" required />
            </div>
            <div>
                <input type="password" name="user_register_confirm_password" iid="user_register_confirm_password" placeholder="<?php esc_attr_e('Repeat Password','mikado-membership') ?>" value="" required />
            </div>
			<div class="mkdf-register-button-holder">
				<?php
				if ( mkdf_membership_theme_installed() ) {
					echo roam_mikado_get_button_html( array(
						'html_type' => 'button',
						'text'      => esc_html__( 'REGISTER', 'mikado-membership' ),
						'type'      => 'solid',
						'size'      => 'small'
					) );
				} else {
					echo '<button type="submit">' . esc_html__( 'REGISTER', 'mikado-membership' ) . '</button>';
				}
				wp_nonce_field( 'mkdf-ajax-register-nonce', 'mkdf-register-security' ); ?>
			</div>
		</fieldset>
	</form>
	<?php do_action( 'mkdf_membership_action_login_ajax_response' ); ?>
</div>