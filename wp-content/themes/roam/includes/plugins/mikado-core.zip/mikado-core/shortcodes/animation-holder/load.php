<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/animation-holder/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/animation-holder/animation-holder.php';