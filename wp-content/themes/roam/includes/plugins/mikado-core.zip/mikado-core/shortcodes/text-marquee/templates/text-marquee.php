<div class="mkdf-text-marquee" <?php echo roam_mikado_inline_style( $text_styles ); ?>>
	<span class="mkdf-marquee-element mkdf-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="mkdf-marquee-element mkdf-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  