<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/info-items/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/info-items/info-items.php';