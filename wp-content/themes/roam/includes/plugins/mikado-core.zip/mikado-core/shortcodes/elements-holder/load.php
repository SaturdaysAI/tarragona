<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/elements-holder/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/elements-holder/elements-holder.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/elements-holder/elements-holder-item.php';