<div class="mkdf-tours-search-content">
	<div <?php mkdf_tours_class_attribute($list_classes);?>>
		<div class="mkdf-tours-row-inner-holder ">
			<?php echo mkdf_tours_get_search_page_items_loop_html($tours_list); ?>
		</div>
	</div>
</div>