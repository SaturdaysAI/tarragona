<?php

get_header();

mkdf_tours_get_title();

mkdf_tours_get_single_tour_item();

get_footer();

?>